<template>
<div class="col-lg-12 col-sm-12">
    <div class="d-flex flex-row flex-wrap justify-content-between">
        <div class="p-1">
            <h5>
                <i class="fas fa-phone fa-2x"></i> Свяжись с
                нами
            </h5>
            <p>01226 246599</p>
        </div>
        <div class="p-1">
            <h5>
                <i class="far fa-envelope-open fa-2x"> </i>
                Отправте емейл
            </h5>
            <p>shop@woodsteel.md.co.md</p>
        </div>
        <div class="p-1">
            <h5>
                <i class="fab fa-facebook fa-2x"></i>
                Найдите нас на FACEBOOK
            </h5>
            <p>shop@woodsteel.md.co.md</p>
        </div>
        <div class="p-1">
            <h5>
                <i class="fab fa-instagram fa-2x"></i>
                Найдите нас на INSTAGRAM
            </h5>
            <p>@woodsteel.md</p>
        </div>
    </div>
</div>
</template>
<script>
export default {
    name: "ContactInfo"
};
</script>