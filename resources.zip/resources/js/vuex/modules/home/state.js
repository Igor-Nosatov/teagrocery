export default {
    new_products: [],
    expensive_products: [],
    types:[],
    random_posts:[],
    neswletter:[],
};
