import * as getters from './types/getters';

export default {

}


