export const POSTS = 'POSTS';
export const POST_BY_TITLE = 'POST_BY_TITLE';