export const GET_POSTS = 'GET_POSTS';
export const GET_POST = 'GET_POST';


