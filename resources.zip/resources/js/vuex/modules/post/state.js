export default {
    posts:[],
};
