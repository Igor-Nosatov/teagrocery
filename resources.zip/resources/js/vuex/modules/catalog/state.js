export default {
    catalog_products: [],
    categories: [],
    prices: [],
    producers: [],
    range:[],
    current_page:'',
};
