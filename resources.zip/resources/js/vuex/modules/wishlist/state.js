export default {
    wishlist_data:[],
};
