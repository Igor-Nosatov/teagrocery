export default {
    product:[],
    cart_product:[],
    wishlist_product:[],
    feeds:[],
    feed_product:[],
};
